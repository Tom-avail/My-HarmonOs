export default class CommonConstants {
}
/**
 * Full width or height.
 */
CommonConstants.FULL_LENGTH = '100%';
/**
 * Title height.
 */
CommonConstants.TITLE_WIDTH = '80%';
/**
 * List default width.
 */
CommonConstants.LIST_DEFAULT_WIDTH = '93.3%';
/**
 * Opacity of default.
 */
CommonConstants.OPACITY_DEFAULT = 1;
/**
 * Opacity of default.
 */
CommonConstants.OPACITY_COMPLETED = 0.4;
/**
 * BorderRadius of list item.
 */
CommonConstants.BORDER_RADIUS = 24;
/**
 * Font weight 500.
 */
CommonConstants.FONT_WEIGHT = 500;
/**
 * Space of column.
 */
CommonConstants.COLUMN_SPACE = 16;
/**
 * agents data.
 */
CommonConstants.TODO_DATA = [
    "早起晨练",
    "准备早餐",
    "阅读名著",
    "学习ArkTS",
    "看剧放松"
];
//# sourceMappingURL=CommonConstants.js.map