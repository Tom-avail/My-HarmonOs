import DataModel from '@bundle:com.example.frist/entry/ets/viewmodel/DataModel';
import CommonConstants from '@bundle:com.example.frist/entry/ets/common/constants/CommonConstants';
import ToDoItem from '@bundle:com.example.frist/entry/ets/view/ToDoItem';
class ToDoListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.totalTasks = [];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.totalTasks !== undefined) {
            this.totalTasks = params.totalTasks;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    aboutToAppear() {
        this.totalTasks = DataModel.getData();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: CommonConstants.COLUMN_SPACE });
            Column.debugLine("pages/ToDoListPage.ets(15:5)");
            Column.width(CommonConstants.FULL_LENGTH);
            Column.height(CommonConstants.FULL_LENGTH);
            Column.backgroundColor({ "id": 16777232, "type": 10001, params: [], "bundleName": "com.example.frist", "moduleName": "entry" });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777229, "type": 10003, params: [], "bundleName": "com.example.frist", "moduleName": "entry" });
            Text.debugLine("pages/ToDoListPage.ets(16:7)");
            Text.fontSize({ "id": 16777226, "type": 10002, params: [], "bundleName": "com.example.frist", "moduleName": "entry" });
            Text.fontWeight(FontWeight.Bold);
            Text.lineHeight({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.frist", "moduleName": "entry" });
            Text.width(CommonConstants.TITLE_WIDTH);
            Text.margin({
                top: { "id": 16777228, "type": 10002, params: [], "bundleName": "com.example.frist", "moduleName": "entry" },
                bottom: { "id": 16777227, "type": 10002, params: [], "bundleName": "com.example.frist", "moduleName": "entry" }
            });
            Text.textAlign(TextAlign.Start);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new ToDoItem(this, { content: item }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            };
            this.forEachUpdateFunction(elmtId, this.totalTasks, forEachItemGenFunction, (item) => JSON.stringify(item), false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ToDoListPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ToDoListPage.js.map