import CommonConstants from '@bundle:com.example.frist/entry/ets/common/constants/CommonConstants';
/**
 * Saving and manipulating data displayed on the page.
 */
export class DataModel {
    constructor() {
        /**
         * Saved Data.
         */
        this.tasks = CommonConstants.TODO_DATA;
    }
    /**
     * Get the data.
     */
    getData() {
        return this.tasks;
    }
}
export default new DataModel();
//# sourceMappingURL=DataModel.js.map